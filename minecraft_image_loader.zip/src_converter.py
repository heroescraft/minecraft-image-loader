from PIL import Image


def color_convert(color, dec=4, to_str=False):
	out = []
	for bit in color:
		out.append(round(bit/255, dec))

	if to_str:
		out = f'{out[0]} {out[1]} {out[2]}'

	return out

def convert(image_name, target):
	im = Image.open(image_name)
	im = im.transpose(Image.FLIP_TOP_BOTTOM)
	pix = im.load()
	size = im.size

	file = ''

	for x in range(size[0]):
		for y in range(size[1]):
			color = color_convert(pix[x, y], to_str=True)
			command = f'execute positioned {target} positioned ~{x/15} ~{y/15} ~ run particle dust {color} 1.0'
			file += command + '\n'

	open('loader/data/mil/functions/image.mcfunction', 'w').write(file)
	open('manager/data/manager/functions/load.mcfunction', 'w').write('datapack enable "file/loader"\ntellraw @a {"text":"Loaded '+ image_name +' at ' + target + '.","color":"green"}')

#232 163 -275

print('''Minecraft Image Loader!
Steps:
	1. Get an image file and drag it into the same directory (folder) as this file.
	2. Type the FULL file name of the image, file extensions INCLUDED!!!''')

image_name = input('Image: ')
print('Type in the coordinates to determine where the image will render.\nx y z format, not x, y, z. (Example: 232 163 -275)')
target = input('Coordinates: ')

convert(image_name, target)
print('''DONE!!
Go to Minecraft, and run:
/function manager:reload
''')
input('Press ENTER to quit...')